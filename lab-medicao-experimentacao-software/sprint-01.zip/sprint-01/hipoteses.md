# LAB 02 - Hipóteses simplificadas

## RQ 01. Sistemas populares são maduros/antigos?
- Hipótese 01: Depende, há sim uma maior gama de repositórios antigos serem mais populares, mas há projetos novos que possuem um hype maior e que acabam tendo maior destaque e popularidade.

## RQ 02. Sistemas populares recebem muita contribuição externa?
- Hipótese 01: Sim, como o uso desses sistemas é maior, eles podem acabar recebendo mais contribuições externas

## RQ 03. Sistemas populares lançam releases com frequência?
- Hipótese 01: Sistemas populares mais antigos mantém menos releases em comparação a sistemas mais recenteres, isso pode ser pelo fato do sistema mais antigo ser mais maduro.

## RQ 04. Sistemas populares são atualizados com frequência?
- Hipótese 01: Sistemas populares tendem a ter um intervalo menos de atualizações.

## RQ 05. Sistemas populares são escritos nas linguagens mais populares?
- Hipótese 01: Talvez sim, pelo fato havem mais pessoas com o conhecimento na linguagem eles podem recebem mais contribuições externas.

## RQ 06. Sistemas populares possuem um alto percentual de issues fechadas?
 - Hipótese 01: Sim, pelo de receberem um alto número de contribuições.